﻿namespace $rootnamespace$
{

	/// <summary>
    /// Place here namespace summary text
    /// </summary>
    /// <remarks>
    /// Some remarks. All XML Documentation defined here will be also included in the NamespaceGroupDoc. Therefore, there is no need to edit comments of the group class below.
    /// </remarks>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }

    /// <inheritdoc/>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceGroupDoc : NamespaceDoc
    {

    }

}
